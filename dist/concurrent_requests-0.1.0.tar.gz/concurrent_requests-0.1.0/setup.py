# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['concurrent_requests']

package_data = \
{'': ['*']}

install_requires = \
['aiofiles==22.1.0', 'aiohttp==3.8.3']

setup_kwargs = {
    'name': 'concurrent-requests',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Pip install\n\n```bash\npip install https://github.com/alexhook/concurrent_requests/raw/master/dist/concurrent_requests-0.1.0.tar.gz\n```\n',
    'author': 'alex',
    'author_email': 'qwertin2505@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
