# Pip install

```bash
pip install https://github.com/alexhook/concurrent_requests/raw/master/dist/concurrent_requests-0.1.0.tar.gz
```
