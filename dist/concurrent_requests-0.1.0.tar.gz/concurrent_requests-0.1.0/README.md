# Pip install

```bash
pip install https://github.com/alexhook/async_download/raw/master/dist/async-download-0.1.0.tar.gz
```
